
import React from 'react'

const Categorylist = () => {
  return (
    <div>Categorylist</div>
  )
}

export default Categorylist