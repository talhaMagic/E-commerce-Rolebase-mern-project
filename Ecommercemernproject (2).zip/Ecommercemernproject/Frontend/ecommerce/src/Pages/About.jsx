import React, { useEffect } from 'react';
import bannerImage from '../images/homepicbanner.jpg'; // Update the path accordingly

const About = () => {
  useEffect(() => {
    // Apply styles directly to the body when the component loads
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.boxSizing = 'border-box';
    document.body.style.backgroundColor = '#000'; // Black background
    document.body.style.overflow = 'hidden'; // Completely hide scrollbars (horizontal and vertical)
  }, []);

  return (
    <div style={styles.container}>
      {/* Banner Section */}
      <div style={{ ...styles.banner, backgroundImage: `url(${bannerImage})` }}>
        <div style={styles.textContainer}>
          <h1 style={styles.bannerText}>About Us</h1>
          <p style={styles.subtitle}>Learn more about our services and vision</p>
        </div>
      </div>

      {/* About Us Section */}
      <div style={styles.aboutContainer}>
        <h2 style={styles.aboutHeading}>Who We Are</h2>
        <p style={styles.aboutText}>
          We are a team of passionate professionals dedicated to delivering top-notch services in web development, mobile apps, and more. Our goal is to provide innovative solutions that empower individuals and businesses.
        </p>
      </div>

      {/* Footer Section */}
      <div style={styles.footer}>
        <p style={styles.footerText}>&copy; 2024 Our Website. All Rights Reserved.</p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    color: '#fff', // White text
    height: '100vh', // Full screen height
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100vw', // Full viewport width
  },
  banner: {
    width: '100%', // Full width of the viewport
    height: '80vh', // Height proportional to the viewport
    backgroundSize: 'cover', // Ensure the image covers the area
    backgroundPosition: 'center', // Center the image
    backgroundRepeat: 'no-repeat', // Ensure no image repetition
    display: 'flex',
    justifyContent: 'flex-start', // Align the content to the left
    padding: '0', // Remove padding
  },
  textContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start', // Align the text to the left
    justifyContent: 'center', // Vertically center the text
    paddingLeft: '50px', // Add padding to the left to prevent text from touching the edge
    paddingRight: '50px', // Optional: Add some padding on the right side for balance
  },
  bannerText: {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: 'red',
    textShadow: '2px 2px 5px black',
    margin: '0', // Remove margin to make subtitle closer
  },
  subtitle: {
    fontSize: '1.5rem',
    color: '#fff',
    textAlign: 'center', // Center the text horizontally
    textShadow: '1px 1px 3px black',
    marginTop: '5px', // Optional: Adjust top margin if needed
    paddingLeft: '0', // No extra padding on the left
  },

  aboutContainer: {
    width: '100%', // Full width
    textAlign: 'center',
    padding: '40px 20px', // Vertical padding for balance
    backgroundColor: '#333', // Dark background for contrast
  },
  aboutHeading: {
    fontSize: '2rem',
    color: 'red',
    marginBottom: '20px',
  },
  aboutText: {
    fontSize: '1.2rem',
    lineHeight: '1.6',
    color: '#ccc',
    maxWidth: '800px', // Optional for content width limit
    margin: '0 auto', // Center content horizontally
  },

  footer: {
    backgroundColor: '#222',
    color: '#fff',
    padding: '20px 0',
    textAlign: 'center',
    width: '100%', // Full-width footer
    marginTop: '40px',
  },

  footerText: {
    fontSize: '1rem',
    color: '#ccc',
  },
};

export default About;
