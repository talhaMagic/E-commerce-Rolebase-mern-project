import React, { useState, useEffect } from 'react';

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: '', // Added role field
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission (e.g., send data to an API)
    console.log(formData);
  };

  useEffect(() => {
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.boxSizing = 'border-box';
    document.body.style.backgroundColor = '#000'; // Black background
    document.body.style.overflow = 'hidden'; // Hide scrollbars
  }, []);

  return (
    <div style={styles.container}>
      {/* Banner Section */}
      <div style={{ ...styles.banner, backgroundImage: `url('your-banner-image-url.jpg')` }}>
      </div>

      {/* Signup Form Section */}
      <div style={styles.signupSection}>
        <div style={styles.formContainer}>
          <h2 style={styles.formHeading}>Create an Account</h2>
          <form onSubmit={handleSubmit} style={styles.form}>
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              style={styles.input}
            />
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              style={styles.input}
            />
            <input
              type="password"
              name="password"
              placeholder="Your Password"
              value={formData.password}
              onChange={handleChange}
              style={styles.input}
            />
            <input
              type="password"
              name="confirmPassword"
              placeholder="Confirm Password"
              value={formData.confirmPassword}
              onChange={handleChange}
              style={styles.input}
            />

            {/* Dropdown for Role */}
            <select
              name="role"
              value={formData.role}
              onChange={handleChange}
              style={styles.select}
            >
              <option value="" disabled>Select Role</option>
              <option value="admin">Admin</option>
              <option value="customer">Customer</option>
            </select>

            <button type="submit" style={styles.submitButton}>Sign Up</button>
          </form>
        </div>
      </div>

      {/* Footer Section */}
      <div style={styles.footer}>
        <p style={styles.footerText}>&copy; 2024 Our Website. All Rights Reserved.</p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    color: '#fff', // White text
    height: '100vh',
    width: '100vw',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Banner Styles
  banner: {
    width: '100%',
    height: '80vh',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    display: 'flex',
    justifyContent: 'flex-start',
    padding: '0',
  },

  // Signup Form Section
  signupSection: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    padding: '40px 20px',
    backgroundColor: '#333',
  },
  formContainer: {
    maxWidth: '600px',
    width: '100%',
    backgroundColor: '#222',
    padding: '30px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
  },
  formHeading: {
    fontSize: '2rem',
    color: 'red',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  input: {
    padding: '12px',
    borderRadius: '5px',
    border: 'none',
    fontSize: '1rem',
    outline: 'none',
    backgroundColor: '#444',
    color: '#fff',
  },
  select: {
    padding: '12px',
    borderRadius: '5px',
    border: 'none',
    fontSize: '1rem',
    outline: 'none',
    backgroundColor: '#444',
    color: '#fff',
  },
  submitButton: {
    padding: '12px 20px',
    backgroundColor: 'red',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    fontSize: '1rem',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },

  // Footer Section
  footer: {
    backgroundColor: '#222',
    color: '#fff',
    padding: '20px 0',
    textAlign: 'center',
    width: '100%',
  },
  footerText: {
    fontSize: '1rem',
    color: '#ccc',
  },
};

export default Signup;
