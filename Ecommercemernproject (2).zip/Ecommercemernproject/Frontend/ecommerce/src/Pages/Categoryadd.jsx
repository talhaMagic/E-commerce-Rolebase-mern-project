import React from 'react'

const Categoryadd = () => {
  return (
    <div>Categoryadd</div>
  )
}

export default Categoryadd