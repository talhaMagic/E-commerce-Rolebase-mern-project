import React from 'react'

const Productadd = () => {
  return (
    <div>Productadd</div>
  )
}

export default Productadd