import React, { useEffect } from 'react';
import bannerImage from '../images/homepicbanner.jpg'; // Update the path accordingly

const Home = () => {
  useEffect(() => {
    // Apply styles directly to the body when the component loads
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.boxSizing = 'border-box';
    document.body.style.backgroundColor = '#000'; // Black background
    document.body.style.overflow = 'hidden'; // Completely hide scrollbars (horizontal and vertical)
  }, []);

  return (
    <div style={styles.container}>
      {/* Banner Section */}
      <div style={{ ...styles.banner, backgroundImage: `url(${bannerImage})` }}>
        <div style={styles.textContainer}>
          <h1 style={styles.bannerText}>Welcome to Our Website</h1>
          <p style={styles.subtitle}>Learn, Build, and Succeed with Us</p>
        </div>
      </div>
      {/* Content Section */}
      <div style={styles.content}>
        <h2 style={styles.heading}>Ecommerce Store</h2>
        <p style={styles.paragraph}>
          We provide top-notch training in web development, mobile app development, and other
          cutting-edge technologies. Our courses are designed to help you succeed in the tech
          industry.
        </p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    color: '#fff', // White text
    height: '100vh', // Full screen height
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100vw', // Full viewport width
  },
  banner: {
    width: '100%', // Full width of the viewport
    height: '80vh', // Height proportional to the viewport
    backgroundSize: 'cover', // Ensure the image covers the area
    backgroundPosition: 'center', // Center the image
    backgroundRepeat: 'no-repeat', // Ensure no image repetition
    display: 'flex',
    justifyContent: 'flex-start', // Align the content to the left
    padding: '0', // Remove padding
  },
  textContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end', // Align the content to the right
    justifyContent: 'center', // Vertically center the text
    paddingLeft: '50px', // Optional padding for balance
    paddingRight: '50px', // Optional padding for balance
  },
  bannerText: {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: 'red',
    textShadow: '2px 2px 5px black',
    margin: '0', // Remove margin to make subtitle closer
  },
  subtitle: {
    fontSize: '1.5rem',
    color: '#fff',
    textAlign: 'right', // Align the subtitle to the right
    textShadow: '1px 1px 3px black',
    marginTop: '5px', // Reduce top margin to move it closer to the heading
  },
  content: {
    width: '100%', // Full width
    textAlign: 'center',
    maxWidth: '800px', // Optional for content width limit
    padding: '20px 0', // Only vertical padding
    margin: '0 auto', // Center content horizontally
  },
  heading: {
    fontSize: '2rem',
    color: 'red',
    marginBottom: '10px',
  },
  paragraph: {
    fontSize: '1rem',
    lineHeight: '1.5',
    color: '#ccc',
  },
};

export default Home;
