import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Components/Navbar'; // Import your Navbar component
import Home from './Pages/Home';
import About from './Pages/About';
import Contact from './Pages/Contact';
import Signup from './Pages/Signup';
import Dashboard from './Pages/Dashboard';
import Service from './Pages/Service';
import Login from './Pages/Login';


const App = () => {
  return (
    <Router>
      <Navbar /> {/* Import and use the Navbar */}
      
      
  
      
      <Routes>
        {/* Define your routes here */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/Dashboard" element={<Dashboard />} />
        <Route path="/Services" element={<Service/>} />
        <Route path="/loginpage" element={<Login/>} />
        
        
        
      </Routes>
    </Router>
  );
}



export default App;
