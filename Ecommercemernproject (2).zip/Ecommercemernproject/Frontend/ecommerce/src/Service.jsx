import React, { useEffect } from 'react';
import bannerImage from '../images/service-banner.jpg'; // Update the path accordingly

const Service = () => {
  useEffect(() => {
    // Apply styles directly to the body when the component loads
    document.body.style.margin = '0';
    document.body.style.padding = '0';
    document.body.style.boxSizing = 'border-box';
    document.body.style.backgroundColor = '#000'; // Black background
  }, []);

  return (
    <div style={styles.container}>
      {/* Banner Section */}
      <div style={{ ...styles.banner, backgroundImage: `url(${bannerImage})` }}>
        <div style={styles.textContainer}>
          <h1 style={styles.bannerText}>Our Services</h1>
          <p style={styles.subtitle}>We Offer Top-Tier Web Development and Mobile App Solutions</p>
        </div>
      </div>

      {/* Content Section */}
      <div style={styles.content}>
        <h2 style={styles.heading}>What We Do</h2>
        <p style={styles.paragraph}>
          Our services include web development, mobile application development, and much more.
          We are committed to delivering high-quality solutions to meet your business needs.
        </p>
        <ul style={styles.list}>
          <li style={styles.listItem}>Custom Website Development</li>
          <li style={styles.listItem}>Mobile App Development</li>
          <li style={styles.listItem}>SEO Optimization</li>
          <li style={styles.listItem}>Ecommerce Solutions</li>
          <li style={styles.listItem}>Consulting and Support</li>
        </ul>
      </div>
    </div>
  );
};

const styles = {
  container: {
    color: '#fff', // White text
    height: '100vh', // Full screen height
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100vw', // Full viewport width
  },

  // Banner Styles
  banner: {
    width: '100%',
    height: '80vh',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    display: 'flex',
    justifyContent: 'flex-start',
    padding: '0',
  },
  textContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingLeft: '50px',
    paddingRight: '50px',
  },
  bannerText: {
    fontSize: '3rem',
    fontWeight: 'bold',
    color: 'red',
    textShadow: '2px 2px 5px black',
    margin: '0',
  },
  subtitle: {
    fontSize: '1.5rem',
    color: '#fff',
    textAlign: 'center',
    textShadow: '1px 1px 3px black',
    marginTop: '5px',
    paddingLeft: '0',
  },

  // Content Section Styles
  content: {
    width: '100%',
    textAlign: 'center',
    maxWidth: '800px',
    padding: '20px 0',
    margin: '0 auto',
  },
  heading: {
    fontSize: '2rem',
    color: 'red',
    marginBottom: '10px',
  },
  paragraph: {
    fontSize: '1rem',
    lineHeight: '1.5',
    color: '#ccc',
  },
  list: {
    listStyleType: 'none',
    padding: '0',
    marginTop: '20px',
  },
  listItem: {
    fontSize: '1.2rem',
    color: '#fff',
    marginBottom: '10px',
    textShadow: '1px 1px 3px black',
  },
};

export default Service;
