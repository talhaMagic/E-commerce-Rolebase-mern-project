import React from 'react';
import { Link } from 'react-router-dom'; // Correct import for Link

const Navbar = () => {
  return (
    <nav style={styles.navbar}>
      <div style={styles.navbarContainer}>
        <div style={styles.logo}>
          <a href="/" style={styles.logoLink}>MAGICO</a>
        </div>
        <ul style={styles.navLinks}>
          <li><Link to="/" style={styles.navLink}>Home</Link></li>
          <li><Link to="/about" style={styles.navLink}>About</Link></li>
          <li><Link to="/contact" style={styles.navLink}>Contact</Link></li>
          <li><Link to="/signup" style={styles.navLink}>Signup</Link></li>
          <li><Link to="/loginpage" style={styles.navLink}>Login</Link></li>
          <li><Link to="/Dashboard" style={styles.navLink}>Dashboard</Link></li>
          {/* <li><Link to="/Services" style={styles.navLink}>Service</Link></li> */}
          
        </ul>
      </div>
    </nav>
  );
};

const styles = {
  navbar: {
    backgroundColor: '#333',
    padding: '10px 0', // Removed horizontal padding
    width: '100%', // Full width
    position: 'fixed', // Keeps navbar fixed at the top
    top: '0',
    left: '0',
    zIndex: '1000',
  },
  navbarContainer: {
    maxWidth: '1200px', // Keeps content centered
    margin: '0 auto', // Center-aligns the navbar content
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    fontSize: '24px',
    fontWeight: 'bold',
  },
  logoLink: {
    color: 'white',
    textDecoration: 'none',
  },
  navLinks: {
    display: 'flex',
    listStyle: 'none',
    margin: '0',
    padding: '0',
  },
  navLink: {
    margin: '0 15px',
    color: 'white',
    textDecoration: 'none',
    fontSize: '18px',
  },
};

export default Navbar;
