import React from 'react';
import { Link } from 'react-router-dom';

const AdminNavbar = () => {
  return (
    <nav style={styles.navbar}>
      <div style={styles.navbarContainer}>
        <div style={styles.logo}>
          <Link to="/Admin/Home" style={styles.logoLink}>Admin MAGICO</Link>
        </div>
        <ul style={styles.navLinks}>
          <li><Link to="/Admin/Home" style={styles.navLink}>Home</Link></li>
          <li><Link to="/Admin/AddProduct" style={styles.navLink}>Add Product</Link></li>
          <li><Link to="/Admin/ProductList" style={styles.navLink}>Product List</Link></li>
          <li><Link to="/Admin/AddCategory" style={styles.navLink}>Add Category</Link></li>
          <li><Link to="/Admin/CategoryList" style={styles.navLink}>Category List</Link></li>
        </ul>
      </div>
    </nav>
  );
};

const styles = {
  navbar: {
    backgroundColor: '#333',
    padding: '10px 0',
    width: '100%',
    position: 'fixed',
    top: '0',
    left: '0',
    zIndex: '1000',
  },
  navbarContainer: {
    maxWidth: '1200px',
    margin: '0 auto',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    fontSize: '24px',
    fontWeight: 'bold',
  },
  logoLink: {
    color: 'white',
    textDecoration: 'none',
  },
  navLinks: {
    display: 'flex',
    listStyle: 'none',
    margin: '0',
    padding: '0',
  },
  navLink: {
    margin: '0 15px',
    color: 'white',
    textDecoration: 'none',
    fontSize: '18px',
  },
};

export default AdminNavbar;
