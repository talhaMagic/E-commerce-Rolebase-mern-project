
const mongoose = require("mongoose");

async function DBconnect(){

    const connect = await mongoose.connect(process.env.DB);

    if(connect) console.log("MONGO DB IS CONNECT");

}

module.exports = {DBconnect}