
const express = require("express");

const app = express();

const dotenv = require("dotenv").config();

app.use(express.urlencoded({extended:true}));

// Middleware to parse JSON bodies
app.use(express.json());  // This will allow your server to parse JSON bodies

//IMPORT MODULE USERS

const {Usercollections} = require("./Models/Users");

//IMPORT DB CONNECTION

const {DBconnect} = require('./Config/db');

//IMPORT USER CONTROLLERS//

const {Registerpage,Registercreate} = require("./Controllers/Usercontroller");

app.route("/Registerget").get(Registerpage);
app.route("/RegisterPOST").post(Registercreate);

//IMPORT USER CONTROLLERS//

const {Rolepage,Rolecreate,RoleDelete,Roleupdate} = require("./Controllers/Rolecontroller");

app.route("/Rolepaget").get(Rolepage);
app.route("/Rolecreate").post(Rolecreate);
app.route("/Roledelete/:id").delete(RoleDelete);
app.route("/Roleupdate/:id").put(Roleupdate);



app.listen(process.env.PORT,function(){

    console.log(`SERVER IS STARTED PORT${process.env.PORT}`);
    DBconnect();
});