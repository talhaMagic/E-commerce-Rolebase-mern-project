
const bcrypt = require("bcrypt");
const {Usercollections } = require("../Models/Users");
const { Roles } = require("../Models/Role");
const { Contact } = require("../Models/Contact");

//METHOD GET
// API http://localhost:5000/Registerget

function Registerpage(req, res) {

    return res.status(200).send({ "message": "Regsiter page GET sucess" });

}

//METHOD POST
// API http://localhost:5000/RegisterPOST

async function Registercreate(req, res) {
    const { username, useremail, userpassword, userrole } = req.body;

    try {
        // Check for missing fields
        if (!username) {
            return res.status(400).send({ "message": "user name is not found" });
        }
        if (!useremail) {
            return res.status(400).send({ "message": "user email is not found" });
        }
        if (!userpassword) {
            return res.status(400).send({ "message": "user password is not found" });
        }
        if (!userrole) {
            return res.status(400).send({ "message": "user role is not found" });
        }

        // Validate username
        const usernamecheker = /^(?!.*[-_]{2})[a-zA-Z][a-zA-Z_-]{1,14}[a-zA-Z]$/;
        if (!usernamecheker.test(username)) {
            return res.status(400).send({
                "message": "Example user123, 123user, user--name, user_ not Invalid Usernames"
            });
        }

        // Validate email
        const useremailchekar = /^[^\s@]+@[^\s@]+\.com$/;
        if (!useremailchekar.test(useremail)) {
            return res.status(400).send({
                "message": "Example user@domain.com is valid. user@domain, user@domain.co are invalid"
            });
        }

        // Validate password
        const passwordchekar = /^[a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]{6,20}$/;
        if (!passwordchekar.test(userpassword)) {
            return res.status(400).send({
                "message": "Password must be between 6-20 characters long and can include alphanumeric and special characters"
            });
        }

        // Check if email already exists
        const existuser = await Usercollections.findOne({
            UserEmail: useremail.toLowerCase(),
        });

        if (existuser) {
            return res.status(400).send({ "message": "user email already exists" });
        }

        // Hash the password
        const encryptpassword = await bcrypt.hash(userpassword, 15);

        // Save the new user
        await Usercollections.create({
            UserName: username,
            UserEmail: useremail.toLowerCase(),
            UserPassword: encryptpassword,
            UserRole: userrole,
        });

        return res.status(201).send({ "message": "User registered successfully" });
    } catch (error) {
        console.error(error);
        return res.status(500).send({ "message": "Internal server error" });
    }
}


module.exports = { Registerpage, Registercreate }