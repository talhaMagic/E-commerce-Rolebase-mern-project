
const { RolesCollection } = require("../Models/Role");

//METHOD GET
// API http://localhost:5000/Rolepaget

async function Rolepage(req, res) {

    const Roleget = await RolesCollection.find();
    return res.status(200).send(Roleget);


}

//METHOD POST
// API http://localhost:5000/Rolecreate

async function Rolecreate(req, res) {
    const { rolename, rolestatus } = req.body;

    // Check if role name is provided
    if (!rolename) {
        return res.status(400).send({ "message": "role name is required" });
    }

    // Check if role status is provided
    if (!rolestatus) {
        return res.status(400).send({ "message": "role status is required" });
    }

    // Regex to check role name format
    const rolenamechekar = /^[A-Za-z]+$/;
    if (!rolenamechekar.test(rolename)) {
        return res.status(400).send({ "message": "Examples of Invalid Role Names: Admin!, Role@123, Lead_Dev" });
    }

    // Regex to check role status
    const rolestatuschekar = /^(active|inactive)$/i;
    if (!rolestatuschekar.test(rolestatus)) {
        return res.status(400).send({ "message": "Example: only choose active and inactive" });
    }

    // Check if the role already exists
    const exist = await RolesCollection.find({
        RoleName: rolename.toLowerCase(),
    });

    if (exist.length > 0) {
        return res.status(400).send({ "message": "role name already exists" });
    }

    // Create the new role
    await RolesCollection.create({
        RoleName: rolename.toLowerCase(),
        RoleStatus: rolestatus,
    });

    return res.status(201).send({ "message": "Role created successfully" });
}

//METHOD DELETE
// API http://localhost:5000/Roledelete/674d68a06b0eda1d5baaf04a

async function RoleDelete(req, res) {

    const Roledelete = req.params.id;
    await RolesCollection.deleteOne({
        _id: Roledelete,
    });

    return res.status(201).send({ "message": "Role sucess delete" });

}

//METHOD UPDATE
// API http://localhost:5000/Roleupdate/674d68a06b0eda1d5baaf04a

async function Roleupdate(req, res) {

    const roleid = req.params.id;

    const getallrolename = await RolesCollection.findOne({ _id: roleid });

    if (!getallrolename) { return res.status(201).send({ "message": "Role name not found" }) }

    const { rolename, rolestatus } = req.body;

    // Check if role name is provided
    if (!rolename) {
        return res.status(400).send({ "message": "role name is required" });
    }

    // Check if role status is provided
    if (!rolestatus) {
        return res.status(400).send({ "message": "role status is required" });
    }

    // Regex to check role name format
    const rolenamechekar = /^[A-Za-z]+$/;
    if (!rolenamechekar.test(rolename)) {
        return res.status(400).send({ "message": "Examples of Invalid Role Names: Admin!, Role@123, Lead_Dev" });
    }

    // Regex to check role status
    const rolestatuschekar = /^(active|inactive)$/i;
    if (!rolestatuschekar.test(rolestatus)) {
        return res.status(400).send({ "message": "Example: only choose active and inactive" });
    }

    await RolesCollection.updateOne(

        { _id: roleid },
        {
            $set: {
                RoleName: rolename.toLowerCase(),
                RoleStatus: rolestatus,
            }
        }
    );

    return res.status(201).send({ "message": "Role update sucess" });

}


module.exports = { Rolepage, Rolecreate, RoleDelete, Roleupdate }