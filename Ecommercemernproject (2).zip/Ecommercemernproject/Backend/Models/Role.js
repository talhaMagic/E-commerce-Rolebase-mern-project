
const mongoose = require("mongoose");

const Role_module = mongoose.Schema({


    RoleName: {
        type: String,
        required: [true, "Role name is required"]
    },

    RoleStatus: {
        type: String,
        enum: {
        values: ["active", "inactive"],
        },
        required: [true, "Role Status is required"],
    },


});
const RolesCollection = mongoose.model("Roles", Role_module);

module.exports = { RolesCollection };