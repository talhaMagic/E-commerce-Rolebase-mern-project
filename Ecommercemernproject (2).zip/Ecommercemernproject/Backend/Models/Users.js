
const mongoose = require("mongoose");

const User_module = mongoose.Schema({

    UserName:{
        type:String,
        required:[true,"User name is required"]
    },

    UserEmail:{
        type:String,
        required:[true,"User email is required"],
        unique:true,
    },

     UserPassword:{
        type:String,
        required:[true,"User Password is required"]
    },

    
    UserRole:{
        type:mongoose.Schema.ObjectId,
        ref: "Roles",
        required:[true,"User Password is required"]
    },

});

  const Usercollections = mongoose.model("Users",User_module);

  module.exports = {Usercollections}