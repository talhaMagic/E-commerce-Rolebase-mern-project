
const mongoose = require("mongoose");

const Contact_module = mongoose.Schema({

    ContactName:{
        type:String,
        required:[true,"Contact name is required"]
    },

    ContactEmail:{
        type:String,
        required:[true,"Contact email is required"],
        unique:true,
    },

     ContactMessage:{
        type:String,
        required:[true,"Contact Message is required"]
    },


});

  const Contactcollections = mongoose.model("Contact",Contact_module);

  module.exports = {Contactcollections}